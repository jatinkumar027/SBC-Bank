Basic Banking System 

Sparks Foundation Web Development Internship Project : Basic Banking System website. A web application used to tranfer virtual money between multiple users and also record the banking transactions/ activities.

The website has the following specification -

  1. A dummy data for atleast 10 customers
  2. Customers cards with basic necessary fields such as name, email, A/C number, IFSC Code, current balance etc.
  3. Transaction flow and Payment receipt.
  4. Transaction log containing history of transactions.

Website Flow : Bank Employee Login Page > Dashboard home page > Select the customer to Pay from > Transfer Money > Select customer to transfer to > Receipt Page > View all Transactions.

Database Flow: Employee table for employee table accessed by DB Admin > Customers Table containing their details > Transaction Table containing Transaction Details
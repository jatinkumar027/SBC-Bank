<?php
    $server_name = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sbc bank";

    $conn = new mysqli($server_name, $username, $password, $dbname);
?>
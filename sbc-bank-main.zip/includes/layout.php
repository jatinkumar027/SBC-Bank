
<script src="https://kit.fontawesome.com/196c90f518.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="icon" type="image/png" href="public/img/icons/bank.ico"/>
